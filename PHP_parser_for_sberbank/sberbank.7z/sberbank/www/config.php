<?php
include 'libs/simple_html_dom.php';
include 'libs/get_ast.php';
include 'inc/mysql_connect.php';

$in_charset = "UTF-8";
$out_charset = "Windows-1251";
#---parse auction page----------------------------
$ex_purchCreateAt="|<purchCreateAt>(.*)<\/purchCreateAt>|";
$ex_purchCode="|<purchCode>(.*)<\/purchCode>|";
$ex_orgName="|<orgName>(.*)<\/orgName>|";
$ex_orgPlace="|<orgPlace>(.*)<\/orgPlace>|";
$ex_orgPostAddress="|<orgPostAddress>(.*)<\/orgPostAddress>|";
$ex_orgEMail="|<orgEMail>(.*)<\/orgEMail>|";
$ex_orgPhones="|<orgPhones>(.*)<\/orgPhones>|";
$ex_purchState="|<purchState>(.*)<\/purchState>|";
#---link to protocol-------------------------------
$ex_prot2docID="|<prot2docID>(.*)<\/prot2docID>|";
#---parse protocol page----------------------------
$ex_reqSuppName="|<reqSuppName>(.*)<\/reqSuppName>|";
$ex_suppINN="|<suppINN>(.*)<\/suppINN>|";
$ex_reqSuppFactAddress="|<reqSuppFactAddress>(.*)<\/reqSuppFactAddress>|";
$ex_reqSuppPostAddress="|<reqSuppPostAddress>(.*)<\/reqSuppPostAddress>|";
$ex_reqSuppPhone="|<reqSuppPhone>(.*)<\/reqSuppPhone>|";
$ex_offerPrice="|<offerPrice>(.*)<\/offerPrice>|";
$ex_docfID="|<docfID>(.*)<\/docfID>|";
$ex_docfName="|<docfName>(.*)<\/docfName>|";
?>
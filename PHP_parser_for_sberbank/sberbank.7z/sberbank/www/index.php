<?php
error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
set_time_limit(0);
include 'config.php';

for ($auction_id=106; $auction_id<=500; $auction_id++){
//--------------------------------
    $file = get_auction_page($auction_id);
    $file = iconv("UTF-8", "Windows-1251", $file);
    $file = html_entity_decode($file);

    preg_match($ex_purchState, $file, $matches);
    if (!isset($matches[1])) continue;
    $purchState=$matches[1];
    if ($purchState!="closed") continue;
    
    preg_match($ex_purchCreateAt, $file, $matches);
    $purchCreateAt=$matches[1];

    preg_match($ex_purchCode, $file, $matches);
    $purchCode=$matches[1];

    preg_match($ex_orgName, $file, $matches);
    $orgName=$matches[1];

    preg_match($ex_orgPlace, $file, $matches);
    $orgPlace=$matches[1];

    preg_match($ex_orgPostAddress, $file, $matches);
    $orgPostAddress=$matches[1];

    preg_match($ex_orgEMail, $file, $matches);
    $orgEMail=$matches[1];

    preg_match($ex_orgPhones, $file, $matches);
    $orgPhones=$matches[1];

    
    //-------------------------------------
    preg_match($ex_prot2docID, $file, $matches);
    $prot2docID=$matches[1];
    //echo "$prot2docID<br>";
    //-------------------------------------
    sleep(2);
    if (isset ($prot2docID)){
        $file = get_doc_page($prot2docID);
        $file = iconv("UTF-8", "Windows-1251", $file);
        $file = html_entity_decode($file);

        preg_match($ex_reqSuppName, $file, $matches);
        $reqSuppName=$matches[1];

        preg_match($ex_suppINN, $file, $matches);
        $suppINN=$matches[1];

        preg_match($ex_reqSuppFactAddress, $file, $matches);
        $reqSuppFactAddress=$matches[1];

        preg_match($ex_reqSuppPostAddress, $file, $matches);
        if (isset($matches[1]))
            $reqSuppPostAddress=$matches[1];

        preg_match($ex_reqSuppPhone, $file, $matches);
        $reqSuppPhone=$matches[1];

        preg_match($ex_offerPrice, $file, $matches);
        $offerPrice=$matches[1];

        preg_match($ex_docfID, $file, $matches);
        $docfID=$matches[1];

        preg_match($ex_docfName, $file, $matches);
        $docfName=$matches[1];

        $docfIDlink = "http://www.sberbank-ast.ru/download.aspx?fid=$docfID";

        //echo "$purchCreateAt<br>$purchCode<br>$orgName<br>$orgPlace<br>$orgPostAddress<br>$orgEMail<br>$orgPhones<br>$reqSuppName<br>$suppINN<br>$reqSuppFactAddress<br>$reqSuppPostAddress<br>$reqSuppPhone<br>$offerPrice<br>$docfID<br>$docfName<br>$docfIDlink<br>$purchState";
        echo "$auction_id data saved";
        $query="INSERT INTO auction VALUES ( '$auction_id', '$purchCreateAt', '$purchCode', '$orgName', '$orgPlace', '$orgPostAddress', '$orgEMail', '$orgPhones', '$reqSuppName', '$suppINN', '$reqSuppFactAddress', '$reqSuppPostAddress', '$reqSuppPhone', '$offerPrice', '$docfID', '$docfName', '$docfIDlink', '$purchState')";
        mysql_query($query, $db_connection);
        sleep(1);
    }
}

?>
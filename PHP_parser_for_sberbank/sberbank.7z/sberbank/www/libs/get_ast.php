<?php
function get_auction_page($PurchaseId){
$ch = curl_init();
//GET ������ ����������� � ������ URL
curl_setopt($ch, CURLOPT_URL, "http://www.sberbank-ast.ru/PurchaseView.aspx?PurchaseID=$PurchaseId");
curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0)');
$auction_page = curl_exec($ch);
curl_close($ch);
return $auction_page;

}

function get_doc_page($docId){
$ch = curl_init();
//GET ������ ����������� � ������ URL
curl_setopt($ch, CURLOPT_URL, "http://www.sberbank-ast.ru/viewDocument.aspx?docID=$docId");
curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0)');
$doc_page = curl_exec($ch);
curl_close($ch);
return $doc_page;

}
?>